# Creating Drops
DROP TABLE IF EXISTS property;
DROP TABLE IF EXISTS sections;
DROP TABLE IF EXISTS owner_account;
DROP TABLE IF EXISTS landmen;

# Creating User accounts
CREATE Table landmen
(Full_Name VARCHAR (255),
Landman_ID BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY);

# Creating Owner Account Table
CREATE TABLE owner_account
(Account_ID BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Account_Names VARCHAR(255),
Address VARCHAR(255),
City VARCHAR(255),
State VARCHAR(255),
Zip_Codes INT,
Landman_ID BIGINT,
Account_Stage VARCHAR(255)
);

# Creating Section Table
CREATE TABLE sections
(STR VARCHAR(10),
Township_Range VARCHAR(10),
Section_Num VARCHAR(10),
Total_Gross_Acres INT,
PRIMARY KEY (STR)
);

# Creating Properties
CREATE TABLE property
(Property_ID BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
STR VARCHAR(10),
Total_Gross_Acres INT,
Percent_Interest Decimal(5,4),
NMA Decimal(5,2),
Land_Description VARCHAR(255),
Account_ID BIGINT,
FOREIGN KEY (STR) REFERENCES sections(STR)
)