DELIMITER //
CREATE PROCEDURE add_owner_account(IN p_Account_Name varchar(255))
BEGIN
	insert into owner_account(Account_Name) values (p_Account_Name);
END //
DELIMITER ;