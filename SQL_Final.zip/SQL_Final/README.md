# SQL_Final_Project

This project makes uses of the folders. Will add more in here when everything is done being typed up
